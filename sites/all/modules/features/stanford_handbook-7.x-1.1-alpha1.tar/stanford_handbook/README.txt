Stanford Policy Handbook
========================

Robust, generalized Drupal Features module for creating policy handbooks

